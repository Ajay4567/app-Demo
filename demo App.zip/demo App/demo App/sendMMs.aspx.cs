﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Text;
using System.Data.SqlClient;

namespace demo_App
{
    public partial class sendMMs : System.Web.UI.Page
    {       
        SqlConnection Con = new SqlConnection("Data Source = 103.21.58.193; Initial Catalog = LetsExam; User ID = girik_infotech; Password=girikinfotechsql@123");
        SqlCommand Cmd;
        string otp = string.Empty;
        public void sendSMS()
        {

            string num = "0123456789";
            int len = num.Length;
            
            
            int otpdigit = 5;
            string finaldigit;
            int getindex;
            for (int i = 0; i < otpdigit; i++)
            {
                do
                {
                    getindex = new Random().Next(0, len);
                    finaldigit = num.ToCharArray()[getindex].ToString();
                }
                while (otp.IndexOf(finaldigit) != -1);
                otp += finaldigit;
            }
                //Your authentication key
                //string authKey = "12222Anpbjnw9KNP57346aef";
                ////Multiple mobiles numbers separated by comma
                //string mobileNumber =txtphn.Text;
                ////Sender ID,While using route4 sender id should be 6 characters long.
                //string senderId = "WEBSMS";
                ////Your message to send, Add URL encoding here.
                //string message = HttpUtility.UrlEncode("Manoj App OTP is : "+otp);

                ////Prepare you post parameters
                StringBuilder sbPostData = new StringBuilder();
                //sbPostData.AppendFormat("authkey={0}", authKey);
                //sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
                //sbPostData.AppendFormat("&message={0}", message);
                //sbPostData.AppendFormat("&sender={0}", senderId);
                //sbPostData.AppendFormat("&route={0}", "default");

                try
                {
            //Call Send SMS API
                string sendSMSUri = "http://sms1.fameitsolutions.in/index.php/smsapi/httpapi/?uname=girik1234&password=123456&sender=TSTSMS&receiver=" + txtphn.Text + "&route=TA&msgtype=1&sms=Manoj App OTP is : " + otp;
                 //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                    //Prepare and Add URL Encoded data
                    UTF8Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(sbPostData.ToString());
                    //Specify post method
                    httpWReq.Method = "POST";
                    httpWReq.ContentType = "application/x-www-form-urlencoded";
                    httpWReq.ContentLength = data.Length;
                    using (Stream stream = httpWReq.GetRequestStream())
                    {
                        stream.Write(data, 0, data.Length);
                    }
                    //Get the response
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    StreamReader reader = new StreamReader(response.GetResponseStream());
                    string responseString = reader.ReadToEnd();

                    //Close the response
                    reader.Close();
                    response.Close();
                }
                catch (SystemException ex)
                {
                    Response.Write(ex.Message.ToString());
                }

                  
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            mv1.ActiveViewIndex = 0;
        }

        protected void btn_Click(object sender, EventArgs e)
        {

            sendSMS();
            Con.Open();
            Cmd = new SqlCommand("insert into girik_infotech.Otp(UserMobileNumber,GeneratedOtp) values('"+txtphn.Text+"','"+otp+"')", Con);
            Cmd.ExecuteNonQuery();
            Con.Close();

            mv1.ActiveViewIndex = 1;
        }

        protected void btnverify_Click(object sender, EventArgs e)
        {
            Con.Open();
            
            SqlDataAdapter adap = new SqlDataAdapter("select * from girik_infotech.Otp where GeneratedOtp = '" + txtotp.Text + "' and UserMobileNumber = '"+txtphn.Text+"'",Con);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            if (dt.Rows[0]["GeneratedOtp"].ToString() == txtotp.Text)
            {
                Response.Redirect("index1.html");
            }
            else
            {
                lblresult.Text = "Entered Otp is wrong";
            }
                    
            Con.Close();
        }
    }
}